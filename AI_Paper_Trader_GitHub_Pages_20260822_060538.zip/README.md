# AI Paper Trader Dashboard

Mobile-first paper trading dashboard.

## Safety

This dashboard is PAPER ONLY.

- DRY_RUN = True
- No buy execution
- No sell execution
- No orders submitted
- No broker state changes

## Dashboard

Open `index.html` through GitHub Pages.

## Current build

Step 256

Generated:
2026-08-22T06:05:38.999536

## Files

- index.html
- dashboard_data.json
- manifest.json
- service-worker.js
- .nojekyll

## Important

`dashboard_data.json` is generated from the paper-trading dashboard
and should be updated whenever the dashboard data changes.
