"""
AI PAPER TRADER — GITHUB PAGES DASHBOARD SYNC

This script copies the current dashboard files into a local
GitHub Pages repository.

IMPORTANT:
This script does NOT execute trades.

It only synchronizes dashboard files.

Usage:

    python sync_dashboard.py /path/to/github/repository

The GitHub repository must already be configured locally.
"""

import os
import sys
import shutil


FILES = [
    "index.html",
    "manifest.json",
    "service-worker.js",
    "dashboard_data.json",
    ".nojekyll",
]


def main():

    if len(sys.argv) != 2:

        print(
            "Usage: python sync_dashboard.py "
            "/path/to/github/repository"
        )

        sys.exit(1)

    repo_dir = os.path.abspath(
        sys.argv[1]
    )

    source_dir = os.path.dirname(
        os.path.abspath(__file__)
    )

    if not os.path.isdir(repo_dir):

        raise FileNotFoundError(
            f"GitHub repository not found: {repo_dir}"
        )

    for filename in FILES:

        source = os.path.join(
            source_dir,
            filename
        )

        destination = os.path.join(
            repo_dir,
            filename
        )

        if os.path.exists(source):

            shutil.copy2(
                source,
                destination
            )

            print(
                f"SYNCED: {filename}"
            )

    print()
    print(
        "Dashboard files synchronized."
    )

    print(
        "Review the changes and commit them "
        "through GitHub."
    )


if __name__ == "__main__":
    main()
